import struct

def build(elapsed):
    packet_id = 0x0800 | 0x0100  # Version=0, Type=0, APID=0x100
    seq = 0xC000  # Sequence Flags: standalone
    length = 4 - 1  # ElapsedSeconds payload size - 1
    header = struct.pack(">HHH", packet_id, seq, length)
    payload = struct.pack(">I", elapsed)
    return header + payload
